import React from "react";

function Note() {
  return (
    <div className="Note">
      <h1>JAVASCRIPT AND REACT.JS</h1>
      <p>this was an amazing bootcamp
        it's very usefull this bootcamp take over by 
        our LOVELY Mr.shaurya sinha sir thank you so much for this 
        BOOTCAMP SHAPEAI
      </p>
      <h1>PYTHON AND MACHINE LEARNING</h1>
      <p>this was an amazing bootcamp
        it's very usefull this bootcamp take over by 
        our LOVELY Mr.shaurya sinha sir thank you so much for this 
        BOOTCAMP SHAPEAI
      </p>
      </div>
  );
}
export default Note;
